<html>
    <head>
        <title></title>
        <link rel="stylesheet" href="style3.css">
           </head>
<body>
<script>
 
 function compareAndCalculateDifference() {
  // Retrieve input field values
  var a=0;
  var b=0;
  const date1Input = document.getElementById('date1').value;
  const date2Input = document.getElementById('date2').value;

  // Create Date objects
  const date1 = new Date(date1Input);
  const date2 = new Date(date2Input);
  const currentDate = new Date();

  // Remove the time portion from currentDate
  currentDate.setHours(0, 0, 0, 0);

  // Compare each date with the current date separately
  let date1Comparison = '';
  let date2Comparison = '';

  if (date1.getTime() < currentDate.getTime()) {
    date1Comparison = 'before';
  } else if (date1.getTime() > currentDate.getTime()) {
    date1Comparison = 'after';
       a++;
  } else {
    date1Comparison = 'the same as';
  }

  if (date2.getTime() < currentDate.getTime()) {
    date2Comparison = 'before';
  } else if (date2.getTime() > currentDate.getTime()) {
    date2Comparison = 'after';
          
    b++;


  } else {
    date2Comparison = 'the same as';
  }

  // Calculate the difference in days
    if( (a>0) && (b>0)){
  const differenceMs = date2.getTime() - date1.getTime();
  const differenceDays = differenceMs / (1000 * 60 * 60 * 24);
 // alert(differenceDays);
     if(differenceDays>0 && differenceDays<100)
        //alert("thanku");
        return true;
        else{  
                     if(differenceDays<0){
           alert("cannot be TO DATE is before than FROM DATE");
            return false;
                     }
                      else{
                        alert("cannot get leave more than 10 days");
                        return false;
                      }
        }
}
else{
           alert("you cannot select a date before the todays date");
           return false;
}

  // Display the result
  //document.getElementById('result').textContent = `Date 1 is ${date1Comparison} Current Date. Date 2 is ${date2Comparison} Current Date. Difference in days: ${differenceDays}`;
}
</script>



    <div>

   <form action="" method="POST" name="myform" onsubmit="return compareAndCalculateDifference()">
    <label for="topic"><strong>Exam type<strong></label><span id="topic"></span>
    <select name="exam_type" id="exam_type" required>
        <option value="First Assessment Exam" >First Assessment Exam</option>
        <option value="Second Assessment Exam">Second Assessment Exam</option>
        <option value="Final Exam">Final Exam</option>

        <option value="other">Other</option>
    </select>
    <strong>Exam-From:</strong>
    <input type="date" id="date1" name="exam_from" required>

<strong>Exam-To:</strong>
<input type="date" id="date2" name="exam_to" required>

<strong>Exam-Time:</strong>
<input type="time" id="time" name="exam_time" required>


      <br>

        <!-- <label for="contact">Salary</label>
        <input type="text" name="salary" id="f1" >  -->

    <input type="submit" value="Submit" name="submit">
  </form>

    </div>

    <?php
         
       include 'connection3.php';
       $dept_id=$_GET['dept_id'];
     //  echo $emp_id;
       if(isset($_POST['submit'])){
          $exam_type=$_POST['exam_type'];
          //echo $topic;
          $exam_from=$_POST['exam_from'];
          $exam_to=$_POST['exam_to'];
          $exam_time=$_POST['exam_time'];

          
        
          

         
        
          
          $query = "INSERT INTO exam(dept_id,exam_from,exam_to,exam_type,exam_time) VALUES ('$dept_id','$exam_from','$exam_to','$exam_type','$exam_time');";
         $result = mysqli_query($conn,$query);
         if($result){
           echo "Exam added sucessfully.";
 echo"<a href='afterlogindepartment2.php?dept_id=$dept_id'>Click Here to proceed.</a> ";
    
        // header('location:afterloginemp2.php');
         // header('location:welcome.php');
         }
          else{
           die(mysqli_error($result));
         }
       }
?>
</body>
</html>
