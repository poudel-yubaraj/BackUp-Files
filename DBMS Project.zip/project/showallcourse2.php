<!DOCTYPE html>
<html lang="en">
<head>
   
    <title>display</title>
    <link rel="stylesheet" href="style3.css">
</head>
<body>
    
    <!-- <a href="insert.php">  <button> Add+</button> </a><br><br> -->
              <table id="customers" border=1px width=100%>
              <caption style="caption-side:top;background-color:#4ae673;font-size:40px;"> Subjects</caption>
                <tr>
                    <th>Course Name </th>
                    <th>Duration</th>
                    
                   
                   

                </tr>
               
               
           

                <!-- php code -->
                <?php      
                        $dept_id=$_GET['dept_id'];
                        $student_id=$_GET['student_id'];
                        include 'connection3.php';
                        $query="SELECT * FROM course where  dept_id=$dept_id";
                        $result=mysqli_query($conn,$query);
                        // fetching the data from a database
                       // $row=mysqli_fetch_assoc($result);  
                        // echo $row['id']; for checking wether the data is fetched or not

                      while(  $row=mysqli_fetch_assoc($result)){
                      //  $subject_id=$row['subject_id'];
                        $subject_name=$row['course_name'];
                        $duration=$row['duration'];
                        
                        $dept_id=$row['dept_id'];

                        $query2="SELECT * FROM dept where dept_id=$dept_id";
               $result2=mysqli_query($conn,$query2);
              $row2=mysqli_fetch_assoc($result2);
              $dept_name=$row2['dept_name'];

           
                       
                    // echo $emp_id;
                       

                     
                    echo"   <tr>
                       <td>".$subject_name."</td>
                       <td>".$duration."</td>
                      
                      
                      

                </tr>";

                        
                      }
                ?>
                </table>
</body>
</html>