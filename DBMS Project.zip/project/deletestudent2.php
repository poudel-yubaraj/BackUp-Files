<?php
   include 'connection3.php';
//    $roll=$_GET['rn'];
//    echo $roll;
      $dept_id=$_GET['dept_id'];
      $student_id=$_GET['student_id'];
      echo $dept_id;
      echo $student_id;
   $query="DELETE FROM student_info WHERE student_id='$student_id' and  dept_id='$dept_id' ";
 $result= mysqli_query($conn,$query);
 if($result){
    echo "Delete sucessfully";
  //header('location:displayemp2.php');

  echo"<a href='afterlogindepartment2.php?dept_id=$dept_id'>Click Here to proceed.</a> ";
 }
 else{
    die(mysqli_error($result));

 }
?>