<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>
</head>
<body>
    
</body>
</html>




<?php
// Include the database connection file
include 'components/connect.php';

// Check if the property ID is set in the URL
if(isset($_GET['get_id'])) {
    $get_id = $_GET['get_id'];
    $select_sender = $conn->prepare("SELECT sender,start,end,property_id FROM `booking` WHERE  id = ?");
    $select_sender->execute([$get_id]);

    $user = $select_sender->fetch(PDO::FETCH_ASSOC);
    $sender = $user['sender'];
    $start= $user['start'];
    $end= $user['end'];
    $property_id= $user['property_id'];

    $select_property = $conn->prepare("SELECT property_name FROM `property` WHERE  id = ?");
    $select_property->execute([$property_id]);
    $property = $select_property->fetch(PDO::FETCH_ASSOC);
    $property_name= $property["property_name"];
 //   echo $sender;

    $select_email = $conn->prepare("SELECT email FROM `users` WHERE  id = ?");
    $select_email->execute([$sender]);

    $email = $select_email->fetch(PDO::FETCH_ASSOC);
    $email = $email['email'];
  //  echo $email;

} else {
    // Redirect to dashboard if property ID is not set
    header('location: dashboard.php');
    exit; // Stop further execution
}
?>

<?php
    $subject = "Regarding your renting"; 

//    $body ="Your renting from ".$start." to ".$end." dates has been approved for the property ".$property_name;


    $body="Dear Sir/Madam,

    We hope this message finds you well. We are pleased to inform you that your request to rent the ".$property_name." from ".$start." to ".$end. " has been approved.
    
    let us know if you have any questions or concerns. Additionally, we will provide instructions on the next steps, including key collection and move-in details, closer to the agreed-upon start date.
    
    We look forward to welcoming you as a tenant and hope you have a pleasant and enjoyable stay at our property. If you require any further assistance, please do not hesitate to contact us.
    
    Thank you for choosing Swift Accomodation!!
    
    Best regards!";















  

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'phpmailer/src/Exception.php';
require 'phpmailer/src/PHPMailer.php';
require 'phpmailer/src/SMTP.php';

try {
    $mail = new PHPMailer(true);

    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'poudelyubaraj420@gmail.com';
    $mail->Password = 'zsqn iirp yfie fmsv';
    $mail->SMTPSecure = 'ssl';
    $mail->Port = 465;

    $mail->setFrom('poudelyubaraj420@gmail.com');

    $mail->addAddress($email);

    $mail->isHTML(true);
    $mail->Subject = $subject;
    $mail->Body = $body;

    $mail->send();

    // echo "
    // <script>
    // alert('Sent successful');
    // document.location.href = 'viewbooking.php';
    // </script>
    // ";
    $email_msg[]='Email sent successfully!';
    
    
} catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}
?>

<?php foreach($email_msg as $message): ?>
<script>
    swal("<?php echo $message; ?>", "", "success").then(function() {
        window.location.href = "viewbooking.php"; // Redirect to home.php after the SweetAlert is closed
    });
</script>
<?php endforeach; ?>
