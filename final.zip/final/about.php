<?php  

include 'components/connect.php';

if(isset($_COOKIE['user_id'])){
   $user_id = $_COOKIE['user_id'];
}else{
   $user_id = '';
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>About Us</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>
   
<?php include 'components/user_header.php'; ?>

<!-- about section starts  -->

<section class="about">

   <div class="row">
      <div class="image">
         <img src="images/about-img.svg" alt="">
      </div>
      <div class="content">
         <h3>why choose us?</h3>
         <p>Experience easy property management with user-friendly features.
         Receive personalized assistance for a smooth and successful property journey.</p>
         <a href="contact.php" class="inline-btn">contact us</a>
      </div>
   </div>

</section>

<!-- about section ends -->

<!-- steps section starts  -->

<section class="steps">

   <h1 class="heading">3 simple steps</h1>

   <div class="box-container">

      <div class="box">
         <img src="images/step-1.png" alt="">
         <h3>Search Property</h3>
         <p>Effortless property discovery begins with our intuitive and comprehensive search.

         </p>
      </div>

      <div class="box">
         <img src="images/step-2.png" alt="">
         <h3>Contact Tenants</h3>
         <p>Seamlessly connect with prospective tenants – Your ideal renters await!</p>
      </div>

      <div class="box">
         <img src="images/step-3.png" alt="">
         <h3>Enjoy Property</h3>
         <p>Indulge in the joy of home sweet home – Enjoy your property!</p>
      </div>

   </div>

</section>

<!-- steps section ends -->

<!-- review section starts  -->

<section class="reviews">

   <h1 class="heading">client's reviews</h1>

   <div class="box-container">

      <div class="box">
         <div class="user">
            <img src="images/pic-11.png.jpg" alt="">
            <div>
               <h3>Hari Tamang</h3>
               <div class="stars">
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star-half-alt"></i>
               </div>
            </div>
         </div>
         <p>Excellent customer support; they promptly addressed my inquiries and provided helpful guidance</p>
      </div>

      <div class="box">
         <div class="user">
            <img src="images/pic-22.png.jpg" alt="">
            <div>
               <h3>Ramila Rai</h3>
               <div class="stars">
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star-half-alt"></i>
               </div>
            </div>
         </div>
         <p>Navigating through listed properties was seamless, and I found my dream flat quickly.</p>
      </div>

      <div class="box">
         <div class="user">
            <img src="images/pic-33.png.jpg" alt="">
            <div>
               <h3>Riju Pokahrel</h3>
               <div class="stars">
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star-half-alt"></i>
               </div>
            </div>
         </div>
         <p>The platform's reach is impressive; my property gained significant exposure, attracting serious customers.</p>
      </div>

      <div class="box">
         <div class="user">
            <img src="images/pic-44.png.jpg" alt="">
            <div>
               <h3>Gyani Shrestha</h3>
               <div class="stars">
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star-half-alt"></i>
               </div>
            </div>
         </div>
         <p>Efficient tools for editing and managing listings; saved me time and effort in the process.</p>
      </div>

      <div class="box">
         <div class="user">
            <img src="images/pic-55.png.jpg" alt="">
            <div>
               <h3>Mahima Tamang</h3>
               <div class="stars">
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star-half-alt"></i>
               </div>
            </div>
         </div>
         <p>Found the perfect tenant for my rental property in no time—thanks to the site's effective matching algorithms</p>
      </div>

      <div class="box">
         <div class="user">
            <img src="images/pic-11.png.jpg" alt="">
            <div>
               <h3>Purna Thakuri</h3>
               <div class="stars">
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star-half-alt"></i>
               </div>
            </div>
         </div>
         <p>Tailored property promotion using diverse listing options for specific needs</p>
      </div>

   </div>

</section>

<!-- review section ends -->










<?php include 'components/footer.php'; ?>

<!-- custom js file link  -->
<script src="js/script.js"></script>

</body>
</html>