<?php  session_start(); ?>
<?php  

include 'components/connect.php';

if(isset($_COOKIE['user_id'])){
   $user_id = $_COOKIE['user_id'];
  
}else{
   $user_id = '';
   header('location:login.php');
}

if(isset($_GET['get_id'])){
    $get_id = $_GET['get_id'];
    $_SESSION['get_id']= $get_id;
 }else{
    $get_id = '';
    header('location:home.php');
 }




$get_id=$_SESSION['get_id'];

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Date Selection and Photo Insertion</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>
    <style>
          
        body {
            font-family: 'Montserrat', sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .main-container {
            max-width: 800px;
            margin: 20px auto;
            background-color: #f9f9f9;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.2);
            overflow: hidden;
        }

        .header-container {
            background-color: #ff6600;
            color: white;
            padding: 20px;
            text-align: center;
        }

        .details-container {
            padding: 30px;
        }

        h2 {
            color: #333;
            margin-bottom: 20px;
        }

        .date-picker {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
        }

        .date-picker label {
            display: block;
            margin-bottom: 5px;
            color: #555;
        }

        input[type="date"] {
            width: calc(50% - 5px);
            padding: 12px;
            border: 2px solid #4caf50;
            border-radius: 6px;
            box-sizing: border-box;
            outline: none;
        }

        .upload-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        input[type="file"] {
            width: calc(50% - 5px);
            padding: 12px;
            border: 2px solid #3498db;
            border-radius: 6px;
            box-sizing: border-box;
            outline: none;
        }

        .submit-btn {
            background-color: #ff6600;
            color: white;
            padding: 14px 24px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 18px;
            transition: background-color 0.3s ease;
        }

        .submit-btn:hover {
            background-color: #303030;
        }

        .disabled-date {
            background-color: #ddd;
        }

        .logo {
            height: 70px;
            margin-right: 10px;
        }
        @media screen and (max-width: 600px) {
    .container {
        max-width: 100%;
        padding: 10px;
    }
}
    </style>

</head>
<body>
    <div class="main-container">
        <div class="header-container">
            <img src="images/arbin.png" alt="Logo" class="logo">
        </div>
        <div class="details-container">
          <u>   <h2> Fill Rent-In Date and Rent-Out Dates</h2></u>
            <form id="dateForm" action="" method="post" enctype="multipart/form-data">
                <div class="date-picker">
                    <label for="start-date">Rent-In Date: &nbsp; &nbsp;</label>
                    <input type="date" id="start-date" name="start-date" required><br><br>
                </div>

                <div class="date-picker">
                    <label for="end-date">Rent-Out Date:</label>
                    <input type="date" id="end-date" name="end-date" required><br><br>
                </div>
             <u>   <h2>Insert your verification photos </h2></u>
                <div class="upload-container">
                    <label for="front-face">Front Face:</label>
                    <input type="file" id="front-face" name="photo1" required><br><br>
                 </div>
                
                 <div class="upload-container">
                    <label for="back-face">Back Face:</label>
                    <input type="file" id="back-face" name="photo2" required><br><br>
                </div>

                <center><input type="submit" value="Proceed" class="submit-btn"><centre>
            </form>
        </div>
    </div>

    <script src="js_for_calendar.js"> </script>
</body>
</html>

<?php 
$booking_msg = array();
$booking_msg_error=array(); // Initialize the booking message array

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $startDate = $_POST["start-date"];
    $endDate = $_POST["end-date"];
    $photo1File = $_FILES["photo1"]["name"];
    $photo2File = $_FILES["photo2"]["name"];
    $uploadDirectory = "images/";
    move_uploaded_file($_FILES["photo1"]["tmp_name"], $uploadDirectory . $photo1File);
    move_uploaded_file($_FILES["photo2"]["tmp_name"], $uploadDirectory . $photo2File);

    $query = "SELECT COUNT(*) AS row_count FROM booking where property_id='$get_id'";
    $result = $conn->query($query);
    $row = $result->fetch(PDO::FETCH_ASSOC);
    $row_count = $row['row_count'];

    $checkSql = "SELECT * FROM booking WHERE ((start BETWEEN :startDate AND :endDate) OR (end BETWEEN :startDate AND :endDate)) AND property_id = :property_id";
    $stmt = $conn->prepare($checkSql);
    $stmt->bindParam(':startDate', $startDate);
    $stmt->bindParam(':endDate', $endDate);
    $stmt->bindParam(':property_id', $get_id);
    $stmt->execute();

    if ($stmt->rowCount() > 0) {
        $booking_msg_error[]='Selected dates are already reserved.!';
      //  echo "Error: Selected dates are already reserved.";
    } else {
        if($user_id != ''){
            $request_id = create_unique_id();
            
            $property_id = $get_id;
            $property_id = filter_var($property_id, FILTER_SANITIZE_STRING);

            $select_receiver = $conn->prepare("SELECT user_id FROM `property` WHERE id = ? LIMIT 1");
            $select_receiver->execute([$property_id]);
            $fetch_receiver = $select_receiver->fetch(PDO::FETCH_ASSOC);
            $receiver = $fetch_receiver['user_id'];

            $send_request = $conn->prepare("INSERT INTO `booking`(id, property_id, sender, receiver,start,end,status,img1,img2) VALUES(?,?,?,?,?,?,?,?,?)");
            $status = ''; // you need to define status variable
            if($send_request->execute([$request_id, $property_id, $user_id, $receiver,$startDate,$endDate,$status,$photo1File,$photo2File])){
                $booking_msg[]='Booking done successfully!';
              
            }
        }
    }
}
$conn = null;
?>

<?php foreach($booking_msg as $message): ?>
<script>
    swal("<?php echo $message; ?>", "", "success").then(function() {
        window.location.href = "home.php"; // Redirect to home.php after the SweetAlert is closed
    });
</script>
<?php endforeach; ?>

<?php foreach($booking_msg_error as $message): ?>
<script>
    swal("<?php echo $message; ?>", "", "error").then(function() {
        window.location.href = "booknow.php"; // Redirect to home.php after the SweetAlert is closed
    });
</script>
<?php endforeach; ?>
