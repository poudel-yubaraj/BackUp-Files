<?php
session_start();
?>

<html>
<head>
  <title></title>
  <style>
    /* CSS styles */

    body {
      margin: 0;
      padding: 0;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
      background-image: url("cam.jpg"); /* Replace "your-image.jpg" with the path to your background image */
      background-size: cover;
      background-position: center;
    }

    div.login-box {
      border-radius: 5px;
      background-color: rgba(242, 242, 242, 0.8); /* Transparent background */
      padding: 20px;
      width: 50%; /* Set the width to cover 50% of the screen */
    }

    input[type=text], input[type=number], input[type=password], select {
      width: 100%;
      padding: 12px 20px;
      margin: 8px 0;
      display: inline-block;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
    }

    input[type=submit] {
      width: 100%;
      background-color: #274160;
      color: white;
      padding: 14px 20px;
      margin: 8px 0;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }

    input[type=submit]:hover {
      opacity:0.7;
    }

    div#error-msg {
      color: red;
      font-weight: bold;
      margin-top: 10px;
      text-align: center;
      color: #274160; /* Set the text color to #274160 */
    }

    div.login-footer {
      margin-top: 20px;
      text-align: center;
    }
  </style>
  <script>
    // JavaScript validation
    function validateForm() {
      var deptID = document.getElementById('dept_id').value;
      var deptName = document.getElementById('dept_name').value;

      // Validate Department ID (Allow only integers)
      if (!/^\d+$/.test(deptID)) {
        document.getElementById('error-msg').innerHTML = 'Invalid Department ID! Please enter a valid integer.';
        return false;
      }

      // Validate Department Name (Allow only characters)
      if (!/^[a-zA-Z]+$/.test(deptName)) {
        document.getElementById('error-msg').innerHTML = 'Invalid Department Name! Please enter alphabetic characters only.';
        return false;
      }

      return true;
    }
  </script>
</head>

<body>
  <div class="login-box">
    <h2 style="text-align: center; color: #274160;">DEPARTMENT LOGIN</h2> <!-- Set the text color to #274160 -->
    <form action="" method="POST" onsubmit="return validateForm();">
      <label for="dept_id">Enter Department ID:</label>
      <input type="text" id="dept_id" name="dept_id" required>

      <label for="dept_name">Enter Department Name:</label>
      <input type="text" id="dept_name" name="dept_name" required>

      <input type="submit" value="Submit" name="submit">
      <div id="error-msg"></div>
    </form>

    <?php
      $count = 0;
      include 'connection3.php';
      if (isset($_POST['submit'])) {
        $dept_id = $_POST['dept_id'];
        $dept_name = $_POST['dept_name'];

        $query = "SELECT * FROM dept";
        $result = mysqli_query($conn, $query);

        while ($row = mysqli_fetch_assoc($result)) {
          $dept_id1 = $row['dept_id'];
          $dept_name1 = $row['dept_name'];

          if (($dept_id1 == $dept_id) && ($dept_name1 == $dept_name)) {
            $count++;
            $_SESSION['dept_id'] = $_POST['dept_id'];
            break;
          }
        }

        if ($count > 0) {
          echo "<div class='login-footer'>
                You Successfully Log In. Please click the next button to continue.
                <a href='afterlogindepartment2.php?dept_id=$dept_id'><button id='loginemp'>Next</button></a>
                </div>";
        } else {
          echo "<script>
                document.getElementById('error-msg').innerHTML = 'Sorry, either the department ID or name is invalid! Please try again!';
              </script>";
        }
      }
    ?>
  </div>

</body>
</html>
