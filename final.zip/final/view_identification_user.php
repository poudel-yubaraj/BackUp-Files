<?php
// Include the database connection file
include 'components/connect.php';

// Check if the property ID is set in the URL
if(isset($_GET['get_id'])) {
    $get_id = $_GET['get_id'];
    echo $get_id;
    // Prepare and execute a query to fetch the identification photo paths from the database
    $select_identification_photos = $conn->prepare("SELECT img1 , img2  FROM `booking` WHERE  id = ?");
    $select_identification_photos->execute([$get_id]);
    // Fetch the identification photo paths
    $identification_photos = $select_identification_photos->fetch(PDO::FETCH_ASSOC);
    // Construct the image paths
    // $img1_path = "../images/" . $identification_photos['img1'];
    // $img2_path = "../images/" . $identification_photos['img2'];

            $img1_path = "images/" . $identification_photos['img1'];
    $img2_path = "images/" . $identification_photos['img2'];
    


} else {
    // Redirect to dashboard if property ID is not set
    header('location: dashboard.php');
    exit; // Stop further execution
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Identification Photos</title>
    <style>
        /* CSS for the modal */
        .modal {
            display: none;
            position: fixed;
            z-index: 1;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0,0,0,0.9);
        }

        .modal-content {
            margin: auto;
            display: block;
            max-width: 80%;
            max-height: 80%;
        }

        .close {
            color: white;
            position: absolute;
            top: 10px;
            right: 25px;
            font-size: 35px;
            font-weight: bold;
            cursor: pointer;
        }

        .close:hover,
        .close:focus {
            color: #999;
            text-decoration: none;
            cursor: pointer;
        }
    </style>
</head>
<body onload="openModal()">

<!-- The modal -->
<div id="identificationModal" class="modal">
    <!-- Modal content -->
    <div class="modal-content">
        <!-- Close button for the modal -->
        <span class="close" onclick="closeModal()">&times;</span>
        <!-- Identification photos displayed in the modal -->
        <img src="<?php echo $img1_path; ?>" class="modal-content" alt="img1 Photo">
        <img src="<?php echo $img2_path; ?>" class="modal-content" alt="img2 Photo">
    </div>
</div>

<!-- Script for modal functionality -->
<script>
    var modal = document.getElementById("identificationModal");

    // Function to open the modal
    function openModal() {
        modal.style.display = "block";
    }

    // Function to close the modal
    function closeModal() {
        modal.style.display = "none";
    }

    // Close the modal when clicking outside of it
    window.onclick = function(event) {
        if (event.target == modal) {
            closeModal();
        }
    }
</script>
</body>
</html>
