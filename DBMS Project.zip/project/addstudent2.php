<html>
    <head>
        <title></title>
        <link rel="stylesheet" href="style3.css">


        <script type="text/javascript">
                function validate()
                    {   
                      
                    }
            </script>
    </head>
</html>

<body>
    <div>

    <form action=" " method="POST" name="myform" onsubmit="return validate()">
    <label for="student_name">Student Name</label><span id="name"></span>
    <input type="text" id="student_name" name="student_name" placeholder="eg.Ram poudel" required>

    

    <label for="student_email">Email</label><span id="eemail"></span>
    <input type="text" id="student_email" name="student_email" placeholder="abc@gmail.com" required>

    <label for="student_password">Password</label><span id="ppassword"></span>
    <input type="password" id="student_password" name="student_password"  required>

    
       
        <label for="student_gpa">GPA</label>
        <input type="text" name="student_gpa" id="student_gpa" required>

       
        <label for="student_dob">DOB</label>
        <input type="date" name="student_dob" id="userDate" required>  <br>

        <!-- <label for="contact">Salary</label>
        <input type="text" name="salary" id="f1" >  -->

    <input type="submit" value="Submit" name="submit">
  </form>

    </div>
</body>

<?php
       include 'connection3.php';
              $dept_id=$_GET['dept_id'];
            //  echo $dept_id;
       if(isset($_POST['submit'])){
          $student_name=$_POST['student_name'];
          //echo $firstname;
        
          $student_email=$_POST['student_email'];
          $student_password=$_POST['student_password'];
          $student_gpa=$_POST['student_gpa'];
          $student_dob=$_POST['student_dob'];
          
  $query="SELECT * FROM dept where dept_id=$dept_id";
               $result=mysqli_query($conn,$query);
              $row=mysqli_fetch_assoc($result);
              $dept_name=$row['dept_name'];
             $faculty_id=$row['faculty_id'];
           
           //  echo $faculty_id;


             $query1="SELECT * FROM faculty where faculty_id=$faculty_id";
               $result1=mysqli_query($conn,$query1);
              $row1=mysqli_fetch_assoc($result1);
              $faculty_name=$row1['faculty_name'];
            

          $query3 = "INSERT INTO student_info (`student_name`, `student_dob`, `student_gpa`, `student_email`, `student_password`, `faculty_id`, `dept_id`) VALUES ('$student_name','$student_dob','$student_gpa','$student_email','$student_password','$faculty_id','$dept_id');";
          $result3 = mysqli_query($conn,$query3);
         if($result3){
           echo "student added sucessfully";
           echo"<a href='afterlogindepartment2.php?dept_id=$dept_id'>Click Here to proceed.</a> ";
 
        // header('location:adminmainpage2.php');
         }
          else{
           die(mysqli_error($result));
         }
       }
?>