<?php  
include 'components/connect.php';

if(isset($_COOKIE['user_id'])){
   $user_id = $_COOKIE['user_id'];
}else{
   $user_id = '';
}

if(isset($_GET['get_id'])){
   $get_id = $_GET['get_id'];
   $_SESSION['get_id']= $get_id;
}else{
   $get_id = '';
   header('location:home.php');
}
?>

<?php
$select_properties = $conn->prepare("SELECT * FROM `property` WHERE id = ? ORDER BY date DESC LIMIT 1");
$select_properties->execute([$get_id]);
if($select_properties->rowCount() > 0){
   while($fetch_property = $select_properties->fetch(PDO::FETCH_ASSOC)){
      $property_id = $fetch_property['id'];
      $royalty= $fetch_property['royalty'];
   }
}
?>

<html>
<head>
   <!-- Add a script to submit the form automatically after page load -->
   <script>
      window.onload = function() {
         document.getElementById('paymentForm').submit();
      };
   </script>
</head>
<body>
   <!-- Redirect to eSewa payment gateway -->
   <form id="paymentForm" action="https://uat.esewa.com.np/epay/main" method="POST" class="flex-btn" >
      <input value="<?php echo $royalty?>" name="tAmt" type="hidden">
      <input value="<?php echo $royalty?>" name="amt" type="hidden">
      <input value="0" name="txAmt" type="hidden">
      <input value="0" name="psc" type="hidden">
      <input value="0" name="pdc" type="hidden">
      <input value="epay_payment" name="scd" type="hidden">
      <input value="<?php echo $get_id;?>" name="pid" type="hidden">
      <input value="http://localhost/final/esewa_payment_success.php" type="hidden" name="su">
      <input value="http://localhost/final/esewa_payment_failed.php" type="hidden" name="fu">
    
   </form>
</body>
</html>
