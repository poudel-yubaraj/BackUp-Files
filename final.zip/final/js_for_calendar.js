document.getElementById("dateForm").addEventListener("submit", function(event) {
    var startDate = document.getElementById("start-date").value;
    var endDate = document.getElementById("end-date").value;

    var currentDate = new Date().toISOString().split("T")[0]; // Get current date in YYYY-MM-DD format

    if (startDate < currentDate || endDate < currentDate) {
        alert("Please select dates from today onwards.");
        event.preventDefault(); // Prevent form submission
    } else if (startDate > endDate) {
        alert("End date must be after start date.");
        event.preventDefault(); // Prevent form submission
    }
});
