<?php
  $conn=mysqli_connect("localhost","root","","esewa");
  if(!$conn){
      die(mysqli_error($conn));
  }
  
?>
  
