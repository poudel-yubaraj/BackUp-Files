<!DOCTYPE html>
<html lang="en">
<head>
   
    <title>display</title>
    <link rel="stylesheet" href="style3.css">
</head>
<body>
    
    <!-- <a href="insert.php">  <button> Add+</button> </a><br><br> -->
              <table id="customers" border=1px width=100%>
              <caption style="caption-side:top;background-color:#4ae673;font-size:40px;"> Subjects</caption>
                <tr>
                    <th> Subject ID</th>
                    <th>Subject Name</th>
                   

                  </tr>
               
               
           

                <!-- php code -->
                <?php   
                
                   include 'connection3.php';

                if(isset($_POST['submit'])){
         
                    $faculty_name=$_POST['faculty_name'];
                  // echo $faculty_name;
                    $dept_name=$_POST['dept_name'];
                    //echo $dept_name;
          
                  
                    $query1="SELECT * FROM faculty where faculty_name='$faculty_name'";
               $result1=mysqli_query($conn,$query1);
                $row1=mysqli_fetch_array($result1);
                         
                         $faculty_id=$row1['faculty_id'];
                       //  echo $faculty_id;
                       
          
          
                         $query2="SELECT * FROM dept where dept_name='$dept_name'";
               $result2=mysqli_query($conn,$query2);
                $row2=mysqli_fetch_array($result2);
                         
                         $dept_id=$row2['dept_id'];
                    //   echo  $dept_id;

                    $query5="SELECT * FROM subject where dept_id=$dept_id and faculty_id=$faculty_id";
                    $result5=mysqli_query($conn,$query5);
                while ($row5=mysqli_fetch_assoc($result5)){

                    $subject_id=$row5['subject_id'];
                    $subject_name=$row5['subject_name'];



                    echo"   <tr>
                    <td>".$subject_id."</td>
                    <td>".$subject_name."</td>
                    

             </tr>";




                }    
                 }
                
                
?>
</table>
   <div id="dbms">  <a href="adminmainpage2dup.php"
   
     style="text-decoration:none;
      align-items: center;
      margin-left: 670px;
      font-size: 20px;
     color: #f30808;


      
      
      
      "
   
   >Home</a>  </div>
</body>
<html>



