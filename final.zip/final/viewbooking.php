

<?php  session_start();?>
<?php  

include 'components/connect.php';

if(isset($_COOKIE['user_id'])){
   $user_id = $_COOKIE['user_id'];

}else{
   $user_id = '';
}

if(isset($_GET['get_id'])){
   $get_id = $_GET['get_id'];
 
   $_SESSION['get_id']= $get_id;
}else{
   $get_id = '';
   header('location:home.php');
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Total Booking </title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>
   
<?php include 'components/user_header.php'; ?>

<section class="my-listings">

   <h1 class="heading">Total Booking</h1>

   <div class="box-container">

   <?php
      $total_images = 0;
      $select_properties = $conn->prepare("SELECT * FROM `booking` WHERE property_id = ?");
      $select_properties->execute([$get_id]);
      if($select_properties->rowCount() > 0){
         while($fetch_property = $select_properties->fetch(PDO::FETCH_ASSOC)){

         $property_id = $fetch_property['property_id'];
         $start= $fetch_property['start'];
         $end= $fetch_property['end'];
         $sender= $fetch_property['sender'];
         $id= $fetch_property['id'];
       
        
         if(!empty($fetch_property['img1'])){
            $image_coutn_02 = 1;
         }else{
            $image_coutn_02 = 0;
         }

         $select_sender = $conn->prepare("SELECT * FROM `users` WHERE id = ?");
         $select_sender->execute([$sender]);
         $fetch_sender = $select_sender->fetch(PDO::FETCH_ASSOC);
 




   ?>
   <!-- form the requests tables  -->


   
   <!-- end of the requests  -->


   <form accept="" method="POST" class="box">
      <input type="hidden" name="property_id" value="<?= $property_id; ?>">
      <div class="thumb">
         <img src="images/<?= $fetch_property['img1']; ?>" alt="hello">
      </div>  
      <h3 class="name">Rent In Date:<?= $fetch_property['start']; ?></h3>
      <h3 class="name">Rent Out Date:<?= $fetch_property['end']; ?></h3>
      <h3 class="name">Name:<?= $fetch_sender['name'] . ' ' . $fetch_sender['lname'] ?></h3>
      <h3 class="name">Number:<?= $fetch_sender['number']; ?></h3>
      <h3 class="name">Email:<?= $fetch_sender['email']; ?></h3>

      <div class="flex-btn">
      <a href="view_identification_user.php?get_id=<?= $id; ?>" class="btn">View Identification</a>


      </div>
      <div class="flex-btn">
      <a href="sendemail.php?get_id=<?= $id; ?>" class="btn">Ensure Renting</a>


      </div>



 
   </form>
   <?php
         }
      }else{
         echo '<p class="empty">no properties added yet! <a href="post_property.php" style="margin-top:1.5rem;" class="btn">add new</a></p>';
      }
      ?>

   </div>

</section>








<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>

<?php include 'components/footer.php'; ?>

<!-- custom js file link  -->
<script src="js/script.js"></script>

<?php include 'components/message.php'; ?>

</body>
</html>