<?php
       include 'connection3.php';
       if(isset($_POST['submit'])){
          $subject_id=$_POST['subject_id'];
           echo $subject_id;
          $subject_name=$_POST['subject_name'];
    echo      $subject_name;
          $faculty_name=$_POST['faculty_name'];
         echo $faculty_name;
          $dept_name=$_POST['dept_name'];
          echo $dept_name;

        
          $query1="SELECT * FROM faculty where faculty_name='$faculty_name'";
     $result1=mysqli_query($conn,$query1);
      $row1=mysqli_fetch_array($result1);
               
               $faculty_id=$row1['faculty_id'];
               echo $faculty_id;
             


               $query2="SELECT * FROM dept where dept_name='$dept_name'";
     $result2=mysqli_query($conn,$query2);
      $row2=mysqli_fetch_array($result2);
               
               $dept_id=$row2['dept_id'];
             echo  $dept_id;
             
          
       
          $query3 = "INSERT INTO subject (`dept_id`, `faculty_id`, `subject_id`, `subject_name`) VALUES ('$dept_id','$faculty_id','$subject_id','$subject_name');";
         $result = mysqli_query($conn,$query3);
         if($result){
           echo "insert sucessfully";
         header('location:adminmainpage2dup.php');
         }
          else{
           die(mysqli_error($result));
         }
       }
?>