<html>
    <head>
        <title></title>
        <link rel="stylesheet" href="style3.css">

        <script type="text/javascript">
                function validate()
                    {   
                        
                        var regName = /^[a-zA-Z]+$/;
                         var regPhone = /^[0-9]+$/;
                         var num=document.myform.dept_id.value;
                        var name=document.myform.dept_name.value;
                       
                    //alert(name);

                       if(!regName.test(name)){
       alert('Please enter valid department name.');
     //  document.getElementById('ffname').value="please enter the valid name";
        document.getElementById('dept_name').focus();
        return false;}
    
         if(! regPhone.test(num)){
       alert('Please enter department ID');
       //document.getElementById('fname').value="please enter the valid name";
        document.getElementById('dept_id').focus();
        return false;}

                    }
            </script>
        
    </head>


<body>
    <div>

    <form action="adddeptprocess2.php" method="POST" name="myform" onsubmit="return validate()">
    <label for="dept_id">Department ID</label><span id="dept_id"></span>
    <input type="text" id="dept_id" name="dept_id" placeholder="eg.001" required>

    <label for="dept_name">Department Name</label><span id="dept_name"></span>
    <input type="text" id="dept_name" name="dept_name" placeholder="eg.Computer" required>

       <?php
        include 'connection3.php';
    $query="SELECT * FROM faculty";
     $result=mysqli_query($conn,$query); 
     ?>

<select name="faculty_name" id="faculty_name"  required>
<option value="" selected="selected" disabled="disabled">- - Select faculty - -</option>
<?php
  while($row=mysqli_fetch_assoc($result)){

	?>
<option value="<?php echo $row['faculty_name'];?>"><?php echo $row['faculty_name'];?></option>
<?php } ?>
</select>

   
    <input type="submit" value="Submit" name="submit">
  </form>

    </div>
</body>
</html>