<?php
session_start();
?>



<!DOCTYPE html>
 
<html>
 
<head>
    <title>
       Student page
    </title>
    <link rel="stylesheet" href="style5.css">
</head>
 
<body>
    <nav class="navbar background">
        <ul class="nav-list">
            <div class="logo">
                <img src="stulogoorg.png">
            </div>



            <?php
include 'connection3.php';

    
              $dept_id=$_GET['dept_id'];
                $student_id=$_GET['student_id'];
    
    echo"&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp; <a href='showstudentrecord2.php?dept_id=$dept_id&student_id=$student_id' style='text-decoration:none;color:black;'>My Records</a>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 
    <a href='showallsubject2.php?dept_id=$dept_id&student_id=$student_id'  style='text-decoration:none;color:black;'>View subjects</a> &nbsp; &nbsp; &nbsp; &nbsp; 
    <a href='viewexam2.php?dept_id=$dept_id&student_id=$student_id'style='text-decoration:none;color:black;' >View Exam shedule</a>&nbsp; &nbsp; &nbsp; &nbsp; 
    <a href='showallcourse2.php?dept_id=$dept_id&student_id=$student_id'style='text-decoration:none;color:black;' >View (extra) Course</a>&nbsp; &nbsp; &nbsp; &nbsp; 
    
    
    ";
           
        ?>













            
            <li><a href="welcome.php">Log Out</a></li>
        </ul>
 
        
    </nav>
     <section class="secondsection">
        <div class="box-main">
            <div class="secondHalf">
                <h1 class="text-big" id="program">
                   
                </h1>
                <p class="text-small">
                <?php
include 'connection3.php';

               $student_id=$_GET['student_id'];
               $dept_id=$_GET['dept_id'];
          //   echo $emp_id;
               $query="SELECT * FROM student_info where student_id=$student_id";
               $result=mysqli_query($conn,$query);
              $row=mysqli_fetch_assoc($result);
               // echo" Hello" .$row['fname'];
               $student_name=$row['student_name'];
            //    $lastname=$row['lastname'];
       echo"Hello  $student_name  <br>
  <pre>  How Are You? </pre>";

  




      ?>
                </p>
                <div class="thumbnail">
                     <!-- <img  align="right" src="stulogoorg.png" alt="image"> -->
                </div>
 
 
            </div>
        </div>
    </section> 
    <footer class="background">
           
        <p class="text-footer">
             
            Copyright ©-All rights are reserved
        </p>
 
 
    </footer>
</body>
 
</html>


















