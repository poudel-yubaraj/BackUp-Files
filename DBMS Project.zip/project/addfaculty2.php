<html>
    <head>
        <title></title>
        <link rel="stylesheet" href="style3.css">


        <script type="text/javascript">
                function validate()
                    {   
                        
                        var regName = /^[a-zA-Z]+$/;
                         var regPhone = /^[0-9]+$/;
                         var num=document.myform.faculty_id.value;
                        var name=document.myform.faculty_name.value;
                       
                    //alert(name);

                       if(!regName.test(name)){
       alert('Please enter valid faculty name.');
     //  document.getElementById('ffname').value="please enter the valid name";
        document.getElementById('faculty_name').focus();
        return false;}
    
         if(! regPhone.test(num)){
       alert('Please enter faculty ID');
       //document.getElementById('fname').value="please enter the valid name";
        document.getElementById('faculty_id').focus();
        return false;}

                    }
            </script>
    </head>
</html>

<body>
    <div>

    <form action="addfacultyprocess2.php" method="POST" name="myform" onsubmit="return validate()">
    <label for="faculty_id">Faculty ID</label><span id="faculty_id"></span>
    <input type="text" id="faculty_id" name="faculty_id" placeholder="eg.001" required>

    <label for="faculty_name">Faculty Name</label><span id="faculty_name"></span>
    <input type="text" id="faculty_name" name="faculty_name" placeholder="eg.Engineering" required>

   
    <input type="submit" value="Submit" name="submit">
  </form>

    </div>
</body>