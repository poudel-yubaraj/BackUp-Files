<?php
session_start();

include 'components/connect.php';

if(isset($_COOKIE['user_id'])){
   $user_id = $_COOKIE['user_id'];  
}else{
   $user_id = '';
   header('location:login.php');
}
$get_id=$_SESSION['get_id'];

// Prepare and execute the SQL query
$sql = "SELECT start, end FROM booking WHERE property_id = ?";
$stmt = $conn->prepare($sql);
$stmt->execute([$get_id]);

// Fetch results
$reservedDates = array();
while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    $reservedDates[] = array('start' => $row['start'], 'end' => $row['end']);
}

// Close the database connection
$conn = null;

// Return reserved dates as JSON
header('Content-Type: application/json');
echo json_encode($reservedDates);
?>
