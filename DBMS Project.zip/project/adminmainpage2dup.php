<!DOCTYPE html>
 
<html>
 
<head>
    <title>
       Student Information System
    </title>
    <!-- <link rel="stylesheet" href="style4.css"> -->
    <style>
        * {
    margin: 0;
    padding: 0;
}

.navbar {
    display: flex;
    align-items: center;
    justify-content: left;
    position: sticky;
    padding-left:10px;
    top: 0;
    cursor: pointer;
}

.background {

    background: #274160;
    background-blend-mode: darken;
    background-size: cover;
}

.nav-list {
    width: 70%;
    display: flex;
    align-items: center;
}

.logo {
    display: flex;
    justify-content: center;
    align-items: center;
}

.logo img {
    width: 180px;
    border-radius: 180px;
}

.nav-list li {
    list-style: none;
    padding: 26px 30px;
}

.nav-list li a {
    text-decoration: none;
    color:white;
}

.nav-list li a:hover {
    opacity:0.7;
}

.rightnav {
    width: 30%;
    text-align: right;
}

#search {
    padding: 5px;
    font-size: 17px;
    border: 2px solid grey;
    border-radius: 9px;
}

.firstsection {
    background-color:  #4adbe6;
    height: 400px;
}

.secondsection {
    background-color: #4adbe6;
    height: 800px;
    background-image: url(screen.png);
    background-repeat: no-repeat;
    background-size: cover;
   
}

.box-main {
    display: flex;
    justify-content: center;
    align-items: center;
    color: red;
    max-width: 80%;
    margin: auto;
    height: 80%;
}

.firsthalf {
    width: 100%;
    display: flex;
    flex-direction: column;
    justify-content: center;
}

.secondhalf {
    width: 30%;
    align-items: right;
}

.secondhalf img {
    width: 70%;
    border: 4px solid rgb(164, 222, 168);
    border-radius: 150px;
    display: block;
    margin: auto;
}

.text-big {
    font-family: 'Piazzolla', serif;
    font-weight: bold;
    font-size: 35px;
}

.text-small {
    font-size: 50px;
    text-align: right;
    color: black;
}

.btn {
    padding: 8px 20px;
    margin: 7px 0;
    border: 2px solid white;
    border-radius: 8px;
    background: none;
    color: white;
    cursor: pointer;
}

.btn-sm {
    padding: 6px 10px;
    vertical-align: middle;
}

.section {
    height: 800px;
    display: flex;
    align-items: center;
    justify-content: center;
    max-width: 90%;
    margin: auto;
}

.section-Left {
    flex-direction: row-reverse;
}

.paras {
    padding: 0px 65px;
}

.thumbnail img {
    width: 250px;
    border: 2px solid black;
    border-radius: 26px;
    margin-top: 19px;
}

.center {
    text-align: center;
}

.text-footer {
    text-align: center;
    padding: 30px 0;
    font-family: 'Ubuntu', sans-serif;
    display: flex;
    justify-content: center;
    color:black;
}
.mainn{
    background-color: rgb(22, 213, 60);
    color: red;
    height: 500px;
    display: flex;
    /* justify-content: top;
    align-items: center; */
}

        </style>
</head>
 
<body>
    <nav class="navbar background">
        <ul class="nav-list">
            <div class="logo">
                <img src="stulogoorg.png" style="align:left">
            </div>
            <li><a href="addfaculty2.php">Add Faculty</a></li>
            <li><a href="adddepartment2.php">Add Department</a></li>
            <li><a href="addsubject2.php">Add Subject</a></li>
            <li><a href="showallfaculty2.php">Show All Faculty</a></li>
            <li><a href="showalldepartment2.php">Show All Department</a></li>
            <li><a href="showsubjectbyadmin2.php">View Subjects</a></li>
          <li><a href="welcome.php">Home page</a></li>
          <li><a href="changingadminpassword2.php"> Change Password</a></li>

        </ul>
 
        
    </nav>
 
    
 
     <section class="secondsection">
        <div class="box-main">
            <div class="secondHalf">
                <h1 class="text-big" id="program">
                   
                </h1>
                <p class="text-small">
                    
               


                </p>
                <div class="thumbnail">
                     <!-- <img  align="right" src="screen.png" alt="image"> -->
                </div>
 
 
            </div>
        </div>
    </section> 
 
    
    <footer class="background">
           
        <p class="text-footer">
             
            Copyright ©-All rights are reserved
        </p>
 
 
    </footer>
</body>
 
</html>