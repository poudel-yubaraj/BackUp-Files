<?php
       include 'connection3.php';
       if(isset($_POST['submit'])){
          $faculty_id=$_POST['faculty_id'];
          
          $faculty_name=$_POST['faculty_name'];
       
          $query = "INSERT INTO faculty(`faculty_id`, `faculty_name`) VALUES ('$faculty_id','$faculty_name');";
         $result = mysqli_query($conn,$query);
         if($result){
           echo "insert sucessfully";
         header('location:adminmainpage2dup.php');
         }
          else{
           die(mysqli_error($result));
         }
       }
?>