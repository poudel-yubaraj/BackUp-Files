<?php

$conn = mysqli_connect('localhost','root','','book') or die('connection failed');

?>