<?php
session_start();

include 'components/connect.php';

if(isset($_COOKIE['user_id'])){
   $user_id = $_COOKIE['user_id'];
}else{
   $user_id = '';
   header('location:login.php');
   exit(); // Ensure to stop further execution
}

$get_id = $_SESSION['get_id'];
$booking_msg = array(); // Initialize the booking message array

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $startDate = $_POST["start-date"];
    $endDate = $_POST["end-date"];
    $photo1File = $_FILES["photo1"]["name"];
    $photo2File = $_FILES["photo2"]["name"];
    $uploadDirectory = "images/";
    move_uploaded_file($_FILES["photo1"]["tmp_name"], $uploadDirectory . $photo1File);
    move_uploaded_file($_FILES["photo2"]["tmp_name"], $uploadDirectory . $photo2File);

    $query = "SELECT COUNT(*) AS row_count FROM booking where property_id='$get_id'";
    $result = $conn->query($query);
    $row = $result->fetch(PDO::FETCH_ASSOC);
    $row_count = $row['row_count'];

    $checkSql = "SELECT * FROM booking WHERE ((start BETWEEN :startDate AND :endDate) OR (end BETWEEN :startDate AND :endDate)) AND property_id = :property_id";
    $stmt = $conn->prepare($checkSql);
    $stmt->bindParam(':startDate', $startDate);
    $stmt->bindParam(':endDate', $endDate);
    $stmt->bindParam(':property_id', $get_id);
    $stmt->execute();

    if ($stmt->rowCount() > 0) {
        echo "Error: Selected dates are already reserved.";
    } else {
        if($user_id != ''){
            $request_id = create_unique_id();
            
            $property_id = $get_id;
            $property_id = filter_var($property_id, FILTER_SANITIZE_STRING);

            $select_receiver = $conn->prepare("SELECT user_id FROM `property` WHERE id = ? LIMIT 1");
            $select_receiver->execute([$property_id]);
            $fetch_receiver = $select_receiver->fetch(PDO::FETCH_ASSOC);
            $receiver = $fetch_receiver['user_id'];

            $send_request = $conn->prepare("INSERT INTO `booking`(id, property_id, sender, receiver,start,end,status,img1,img2) VALUES(?,?,?,?,?,?,?,?,?)");
            $status = ''; // you need to define status variable
            if($send_request->execute([$request_id, $property_id, $user_id, $receiver,$startDate,$endDate,$status,$photo1File,$photo2File])){
                $booking_msg[]='Booking done successfully!';
              
            }
        }
    }
}

$conn = null;
?>

<!DOCTYPE html>
<html>
<head>
    <title>Display Booking Messages</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>
</head>
<body>






</body>
</html>
