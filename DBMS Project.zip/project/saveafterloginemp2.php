<!DOCTYPE html>
 
<html>
 
<head>
    <title>
       Employee Management system
    </title>
    <link rel="stylesheet" href="style.css">
</head>
 
<body>
    <nav class="navbar background">
        <ul class="nav-list">
            <div class="logo">
                <img src="friends.png">
            </div>
            <li><a href="#web">Admin Login</a></li>
            <li><a href="emplogin2.php">Employee Login</a></li>
            <li><a href="#course">About Us</a></li>
            <li><a href="#">Contact Us</a></li>
        </ul>
 
        <div class="rightNav">
            <input type="text" name="search" id="search">
            <button class="btn btn-sm">Search</button>
        </div>
    </nav>
     <section class="secondsection">
        <div class="box-main">
            <div class="secondHalf">
                <h1 class="text-big" id="program">
                   
                </h1>
                <p class="text-small">
                      EMPLOYEE MANAGEMENT SYSTEM
                </p>
                <div class="thumbnail">
                     <!-- <img  align="right" src="friends.png" alt="image"> -->
                </div>
 
 
            </div>
        </div>
    </section> 
    <footer class="background">
           
        <p class="text-footer">
             
            Copyright ©-All rights are reserved
        </p>
 
 
    </footer>
</body>
 
</html>


















<?php
include 'connection2.php';
               $emp_id=$_GET['emp_id'];
               echo $emp_id;
               $query="SELECT * FROM employee where emp_id=$emp_id";
               $result=mysqli_query($conn,$query);
               $row=mysqli_fetch_assoc($result);
            //    echo $row['name'];

    echo"<a href='showsalary2.php?emp_id=$emp_id'>Show My salary</a>
    <a href='showrecord2.php?emp_id=$emp_id'>Show My Records</a>
    <a href='seemyproject2.php?emp_id=$emp_id'>See My project</a>
    
    
    ";
               ?>
 