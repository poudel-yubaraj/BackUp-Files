<!DOCTYPE html>
<html>
<head>
    <title>Student Information System</title>
    <style>
        * {
    margin: 0;
    padding: 0;
}

html, body {
    height: 100%;
}

.navbar {
    display: flex;
    align-items: center;
    justify-content: left;
    position: sticky;
    top: 0;
    cursor: pointer;
    padding-left: 10px;
    z-index: 1; /* Add z-index to keep the navbar on top */
}

.background {
    background: #274160;
    background-blend-mode: darken;
    background-size: cover;
}

.nav-list {
    width: 70%;
    display: flex;
    align-items: center;
}

.logo {
    display: flex;
    justify-content: center;
    align-items: center;
}

.logo img {
    width: 80px;
    border-radius: 80px;
}

.nav-list li {
    list-style: none;
    padding: 26px 30px;
}

.nav-list li a {
    text-decoration: none;
    color: white;
    font-size: 18px;
}

.nav-list li a:hover {
    opacity:0.7;
}

.rightNav {
    width: 30%;
    text-align: right;
}

#search {
    padding: 5px;
    font-size: 17px;
    border: 2px solid grey;
    border-radius: 9px;
}

.secondsection {
    background-image: url("cambridge.jpg");
    background-size: cover;
    background-position: center;
    background-repeat: no-repeat;
    height: 800px;
    margin-top: -70px;
}

.text-small {
    color: #274160;
    font-size: 35px;
    text-align: justify;
    text-align-last: center;
}

.marquee-text {
    font-family: 'Piazzolla', serif;
    font-weight: bold;
    font-size: 35px;
    color: white;
    text-align: center;
    margin-top: 50px;
}

.footer {
    background-color: #274160;
    color: white;
    padding: 30px 0;
    width: 100%;
    height: 120px; /* Increased height to accommodate the logo and footer text */
    position: relative; /* Added position relative to the footer */
}

.container {
    display: flex;
    justify-content: space-between;
    align-items: center;
    position: relative; /* Added position relative to the container */
}

.logo-container {
    display: flex;
    align-items: flex-end; /* Align the logo and footer text to the bottom */
}

.logo-image {
    width: 200px;
    height: 100px;
}

.footer-text {
    color: white;
    position: absolute;
    bottom: 0;
    left: 50%; /* Set the left position to 50% */
    transform: translateX(-50%); /* Move the element back by 50% of its width */
    margin-bottom: 10px; /* Add margin to create spacing between the logo and text */
}

.footer-right {
    flex: 1;
    text-align: right;
}

.footer-left {
    flex: 1;
    text-align: left;
}

.footer-links {
    list-style: none;
    padding: 13px;
}

.footer-links li {
    margin-bottom: 10px;
}

.footer-links a {
    color: white;
    text-decoration: none;
}

.footer-links a:hover {
    opacity: 0.7;
}

.background2 {
    background: #274160;
    background-blend-mode: darken;
    background-size: cover;
}

.text-footer2 {
    color: white;
    text-align: center;
}
</style>
</head>
<body>
    <nav class="navbar background">
        <ul class="nav-list">
            <div class="logo">
                <img src="stulogoorg.png" style="width: 200px; height: 100px;">
            </div>
            <li><a href="adminlogin2.php">Admin Login</a></li>
            <li><a href="departmentlogin.php">Department Login</a></li>
            <li><a href="studentlogin2.php">Student Login</a></li>
            <li><a href="contactus22.php">Contact Us</a></li>
        </ul>
        <div class="rightNav">
            <input type="text" name="search" id="search">
            <button class="btn btn-sm">Search</button>
        </div>
    </nav>
    <br>
    <br>


    <section class="secondsection">
        <div class="box-main">
            <div class="secondHalf">
                <marquee behavior="scroll" direction="left" scroll amount="100">
                    <h1 class="marquee-text">WELCOME!!</h1>
                </marquee>
                <!-- <p class="text-small">
                    The Student Management System is a comprehensive platform designed to efficiently manage student information and related tasks. It provides features such as student enrollment, course tracking, exam schedule management, and communication between students and administrators .
                </p> -->
            </div>
        </div>
    </section>

    <footer class="footer">
        <div class="container">
            <div class="footer-left">
                <ul class="footer-links">
                    <li><u><strong>Useful Links</strong></u></li>
                    <li><a href="welcome.php">Home</a></li>
                    <li><a href="about2.php">About Us</a></li>
                    <li><a href="#">Services</a></li>
                </ul>
            </div>
            <div class="logo-container">
                <div class="logo-wrapper">
                    <img src="stulogoorg.png" alt="logo" class="logo-image">
                    <p class="footer-text">All rights reserved &copy; 2023</p>
                </div>
            </div>
            <div class="footer-right">
                <ul class="footer-links">
                    <li><u><strong>Location</strong></u></li>
                    <li><a href="#">Kritipur,</a></li>
                    <li><a href="#">Kathmandu</a></li>
                </ul>
            </div>
        </div>
    </footer>
</body>
</html>
