<?php
   $conn= mysqli_connect("localhost","root","","student");
         
   if(!$conn){
            die(mysqli_error($conn));
          }
          
?>