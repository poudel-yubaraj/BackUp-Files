<?php
       include 'connection3.php';
       if(isset($_POST['submit'])){
          $dept_id=$_POST['dept_id'];
          //echo $firstname;
          $dept_name=$_POST['dept_name'];
          $faculty_name=$_POST['faculty_name'];
        
          $query1="SELECT * FROM faculty where faculty_name='$faculty_name'";
     $result1=mysqli_query($conn,$query1);
      $row=mysqli_fetch_array($result1);
               
               $faculty_id=$row['faculty_id'];
             
          
       
          $query = "INSERT INTO dept (`dept_id`, `faculty_id`, `dept_name`) VALUES ('$dept_id','$faculty_id','$dept_name');";
         $result = mysqli_query($conn,$query);
         if($result){
           echo "insert sucessfully";
         header('location:adminmainpage2dup.php');
         }
          else{
           die(mysqli_error($result));
         }
       }
?>