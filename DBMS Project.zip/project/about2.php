<!DOCTYPE html>
<html>
<head>
    <title>Student Information System</title>
    <style>
        * {
            margin: 0;
            padding: 0;
        }

        html, body {
            height: 100%;
        }

        .navbar {
            display: flex;
            align-items: center;
            justify-content: left;
            position: sticky;
            top: 0;
            cursor: pointer;
            padding-left: 10px;
            z-index: 1;
        }

        .background {
            background: #274160;
            background-blend-mode: darken;
            background-size: cover;
        }

        .nav-list {
            width: 70%;
            display: flex;
            align-items: center;
        }

        .logo {
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .logo img {
            width: 200px;
            height: 100px;
            border-radius: 80px;
        }

        .nav-list li {
            list-style: none;
            padding: 26px 30px;
        }

        .nav-list li a {
            text-decoration: none;
            color: white;
            font-size: 18px;
        }

        .nav-list li a:hover {
            opacity: 0.7;
        }

        .rightNav {
            width: 30%;
            text-align: right;
        }

        #search {
            padding: 5px;
            font-size: 17px;
            border: 2px solid grey;
            border-radius: 9px;
        }

        .secondsection {
            background-image: url("home.png");
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            height: 400px;
            margin-top: -70px;
        }

        .text-small {
            color: #274160;
            font-size: 35px;
            text-align: justify;
            text-align-last: center;
        }

        .marquee-text {
            font-family: 'Piazzolla', serif;
            font-weight: bold;
            font-size: 35px;
            color: #274160;
            text-align: center;
            margin-top: 50px;
        }

        .footer {
            background-color: #274160;
            color: white;
            padding: 30px 0;
            width: 100%;
            height: 120px;
            position: relative;
        }

        .container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: relative;
        }

        .logo-container {
            display: flex;
            align-items: flex-end;
        }

        .logo-image {
            width: 200px;
            height: 100px;
        }

        .footer-text {
            color: white;
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            margin-bottom: 10px;
        }

        .footer-right {
            flex: 1;
            text-align: right;
        }

        .footer-left {
            flex: 1;
            text-align: left;
        }

        .footer-links {
            list-style: none;
            padding: 13px;
        }

        .footer-links li {
            margin-bottom: 10px;
        }

        .footer-links a {
            color: white;
            text-decoration: none;
        }

        .footer-links a:hover {
            opacity: 0.7;
        }

        .background2 {
            background: #274160;
            background-blend-mode: darken;
            background-size: cover;
        }

        .text-footer2 {
            color: white;
            text-align: center;
        }

        /* Added styles */
        .section-content {
            color: #274160; /* Change the color of the paragraph */
            font-size: 20px; /* Change the font size of the paragraph */
            margin-bottom: 30px; /* Add margin at the bottom for spacing */
        }
    </style>
</head>
<body>
    <nav class="navbar background">
        <ul class="nav-list">
            <div class="logo">
                <img src="stulogoorg.png">
            </div>
            <li><a href="adminlogin2.php">Admin Login</a></li>
            <li><a href="departmentlogin.php">Department Login</a></li>
            <li><a href="studentlogin2.php">Student Login</a></li>
            <li><a href="contactus22.php">Contact Us</a></li>
            <!-- <li><a href="welcome.php">Home</a></li> -->
        </ul>
        <div class="rightNav">
            <input type="text" name="search" id="search">
            <button class="btn btn-sm">Search</button>
        </div>
    </nav>

    <p class="section-content"><b>What is Student Information System?</b><br><br>
        A student information system (SIS) is a software application used by educational institutions to manage student-related data and information. It serves as a comprehensive database that stores and organizes various student records, including personal details, academic information, attendance, grades, schedules, and more.</p>

    <p class="section-content">The primary purpose of a student information system is to streamline administrative processes and enhance communication between administrators, teachers, students, and parents. By centralizing student data, SIS enables efficient management of student information, facilitates timely and accurate reporting, and provides valuable insights for decision-making.</p>

    <p class="section-content"><b>Why Student Information System is required?</b><br><br>
        Student Records Management: SIS stores and manages student demographic information, contact details, enrollment history, and other relevant data.<br>
        Enrollment and Registration: It facilitates the registration process, including online enrollment, course selection, and managing waitlists.<br>
        Attendance Tracking: SIS allows teachers to record and track student attendance, monitor patterns, and generate reports for administrative purposes.<br>
        Grading and Transcripts: It supports the grading process, calculates grade point averages (GPAs), and generates transcripts and report cards.<br>
        Scheduling: SIS assists in creating class schedules, assigning teachers, managing room allocations, and resolving scheduling conflicts.<br>
        Communication and Collaboration: It provides channels for communication between administrators, teachers, students, and parents, such as messaging, notifications, and online portals.<br>
        Reporting and Analytics: SIS generates various reports, statistical analyses, and performance metrics to assess student progress, identify trends, and aid decision-making.<br>
        Integration and Data Exchange: SIS can integrate with other systems within an educational institution, such as learning management systems, financial systems, and assessment tools, to streamline data exchange and improve efficiency.<br>
        Student information systems are commonly used in schools, colleges, universities, and other educational institutions to streamline administrative tasks, improve data accuracy, and enhance communication and collaboration among stakeholders.</p>

    <footer class="footer">
        <div class="container">
            <div class="footer-left">
                <ul class="footer-links">
                    <li><u><strong>Useful Links</strong></u></li>
                    <li><a href="welcome.php">Home</a></li>
                    <li><a href="about2.php">About Us</a></li>
                    <li><a href="#">Services</a></li>
                </ul>
            </div>
            <div class="logo-container">
                <div class="logo-wrapper">
                    <img src="stulogoorg.png" alt="logo" class="logo-image">
                    <p class="footer-text">All rights reserved &copy; 2023</p>
                </div>
            </div>
            <div class="footer-right">
                <ul class="footer-links">
                    <li><u><strong>Location</strong></u></li>
                    <li><a href="#">Kritipur,</a></li>
                    <li><a href="#">Kathmandu</a></li>
                </ul>
            </div>
        </div>
    </footer>
</body>
</html>
