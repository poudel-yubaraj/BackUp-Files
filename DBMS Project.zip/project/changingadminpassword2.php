<html>
    <head>
        <title></title>
        <link rel="stylesheet" href="style3.css">
    </head>

<script type="text/javascript">
                function validate()
                    {   
                        var password2=document.myform.password2.value;
                        var password3=document.myform.password3.value;

//alert(password3);
                        
                        


           if(password2.length<6){
                 alert("password must be greator than 6 character");     
               return false;
           }
            if(password3.length<6){
                 alert("password must be greator than 6 character");     
               return false;
           }


          if(differenceDays<365 ){
            alert("jjjjjjjjjjjjjjj");
            return false;
          }




                            if((document.myform.email.value=="") || (atpos<1||dotpos<atpos+2||dotpos+2>=x.length))
                                {
                                    alert("Please Provide Valid Email")
                                    document.myform.email.focus();
                                    return false;
                                }
                            if(document.myform.zip.value==""||isNaN(document.myform.zip.value)||
                            document.myform.zip.value.length!=5)
                                {   
                                    alert("Please Provide a zip in the format #####");
                                    document.myform.zip.focus();
                                    return false;
                                }
                            if(document.myform.country.value=="-1")
                                {
                                    alert("Please provide your country");
                                    return false;
                                }
                            if (isNaN(num)){  
                                alert("please enter numeric value only");
  document.getElementById("numloc").innerHTML="Enter Numeric value only";  
  return false;  
}else{  
  return true;  
  } 
  
  
  
                                


                            alert("All fields are filled.\n Thank you ");
                            exit();
                    }
            </script>


























    
<body>
<nav id='demo'>ADMIN LOGIN</nav>
    <div>

    <form action="" method="POST" name="myform" onsubmit="return validate()">
    <label for="email">Enter Your Email:</label>
    <input type="text" id="email" name="email" required>

    <label for="password">Enter Your current Password:</label>
    <input type="password" id="password" name="password" required>


    <label for="password2">Enter Your New Password:</label>
    <input type="password" id="password2" name="password2" required>

    <label for="password3">Retype Your New Password:</label>
    <input type="password" id="password3" name="password3" required>

    

    <input type="submit" value="Submit" name="submit">
       <div id="check"></div>
  </form>

    </div>

    <div></div>

</body>
</html>

<?php
         $count=0;
         $count1=0;

       include 'connection3.php';
       if(isset($_POST['submit'])){
          $email1=$_POST['email'];
          $password2=$_POST['password2'];
          $password3=$_POST['password3'];

        


          //echo $firstname;
         
          $password1=$_POST['password'];

          $query="SELECT * FROM  admin";
          $result=mysqli_query($conn,$query);
         
          while($row=mysqli_fetch_assoc($result)){
            $email=$row['email'];
             $password=$row['password'];
             $admin_id=$row['admin_id'];
                    
                    if(($email1==$email)&&($password1==$password)){
                       // echo "password is found";
                       $count++;
                         if($password2==$password3){
                          
                          $query="UPDATE admin SET  password='$password2' WHERE admin_id=$admin_id";                   
                          $result =  mysqli_query($conn,$query);
                                 $count1++;
                               header('location:adminmainpage2dup.php');
                         }
                         else{

                          echo"<script>
                          document.getElementById('check').innerHTML='Your new password doesnot match';
                           </script>";
                         }
                        
                    }
                         
          
                else{
                  
                  // header('location:emplogin2.php');
                     echo"<script>
                    document.getElementById('check').innerHTML='Sorry either your email or Password is invalid ! Please try again!!';
                     </script>";
                 //  echo "Sorry either ID or Password is invalid !";
               //   header('location:emplogin2.php');
                }


              //  if($count1==0){
                  
                  // header('location:emplogin2.php');
                //     echo"<script>
                  //  document.getElementById('check').innerHTML='Your new password doesnot match';
                    // </script>";
                 //  echo "Sorry either ID or Password is invalid !";
               //   header('location:emplogin2.php');
                //}
        
              }
        }
?>