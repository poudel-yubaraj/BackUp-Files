<!DOCTYPE html>
<html lang="en">
<head>
   
    <title>display</title>
    <link rel="stylesheet" href="style3.css">
</head>
<body>
    
    <!-- <a href="insert.php">  <button> Add+</button> </a><br><br> -->
              <table id="customers" border=1px width=100%>
              <caption style="caption-side:top;background-color:#4ae673;font-size:40px;"> My records</caption>
                <tr>
                    <th> Student ID</th>
                    <th>Name</th>
                    <th>DOB</th>
                    <th>GPA</th>
                    <th>Password</th>
                    <th>Department</th>
                    <th>Faculty</th>
                   

                </tr>
               
               
           

                <!-- php code -->
                <?php      
                        $dept_id=$_GET['dept_id'];
                        $student_id=$_GET['student_id'];
                        include 'connection3.php';
                        $query="SELECT * FROM student_info where student_id=$student_id and dept_id=$dept_id";
                        $result=mysqli_query($conn,$query);
                        // fetching the data from a database
                       // $row=mysqli_fetch_assoc($result);  
                        // echo $row['id']; for checking wether the data is fetched or not

                        $row=mysqli_fetch_assoc($result);
                        $student_id=$row['student_id'];
                        $student_name=$row['student_name'];
                        $student_dob=$row['student_dob'];
                        $student_gpa=$row['student_gpa'];
                        $student_password=$row['student_password'];
                        $dept_id=$row['dept_id'];

                        $query2="SELECT * FROM dept where dept_id=$dept_id";
               $result2=mysqli_query($conn,$query2);
              $row2=mysqli_fetch_assoc($result2);
              $dept_name=$row2['dept_name'];

             $faculty_id=$row['faculty_id'];

             $query1="SELECT * FROM faculty where faculty_id=$faculty_id";
             $result1=mysqli_query($conn,$query1);
            $row1=mysqli_fetch_assoc($result1);
            $faculty_name=$row1['faculty_name'];
                       
                       
                    // echo $emp_id;
                       

                     
                    echo"   <tr>
                       <td>".$student_id."</td>
                       <td>".$student_name."</td>
                       <td>".$student_dob."</td>
                       <td>".$student_gpa."</td>
                       <td>".$student_password."</td>
                       <td>".$dept_name."</td>
                       <td>".$faculty_name."</td>
                      

                </tr>";

                        

                ?>
                </table>
</body>
</html>