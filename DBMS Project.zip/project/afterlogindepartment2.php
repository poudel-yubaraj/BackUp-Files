<?php
session_start();
?>



<!DOCTYPE html>
 
<html>
 
<head>
    <title>
      Student information system
    </title>
    <link rel="stylesheet" href="style5.css">
</head>
 
<body>
    <nav class="navbar background">
        <ul class="nav-list">
            <div class="logo">
                <img src="stulogoorg.png">
            </div>



            <?php
include 'connection3.php';

    
              $dept_id=$_GET['dept_id'];

            

    echo"&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp; <a href='addstudent2.php?dept_id=$dept_id' style='text-decoration:none;color:black;'>Add Students</a>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 
    <a href='showallstudent2.php?dept_id=$dept_id'  style='text-decoration:none;color:black;'>Show All Students</a> &nbsp; &nbsp; &nbsp; &nbsp; 
    <a href='scheduleexam2.php?dept_id=$dept_id'style='text-decoration:none;color:black;' >schedule Exam</a>&nbsp; &nbsp; &nbsp; &nbsp; 
    <a href='handlecourse2.php?dept_id=$dept_id'style='text-decoration:none;color:black;' >Add(extra) Course</a>&nbsp; &nbsp; &nbsp; &nbsp; 
    
    
    ";
           
        ?>



            <li><a href="welcome.php">Log Out</a></li>
        </ul>
 
    </nav>
     <section class="secondsection">
        <div class="box-main">
            <div class="secondHalf">
                <h1 class="text-big" id="program">
                   
                </h1>
                <p class="text-small">
                <?php
include 'connection3.php';

    
               $dept_id=$_GET['dept_id'];
          
               $query="SELECT * FROM dept where dept_id=$dept_id";
               $result=mysqli_query($conn,$query);
              $row=mysqli_fetch_assoc($result);
               
               $dept_name=$row['dept_name'];
             

   echo" <marquee class='marq'
  
   behavior=alternate
   direction='left'
   loop=''> 
   $dept_name<br>
     department
     </marquee>
     ";




      ?>
                </p>
                <div class="thumbnail">
                     <!-- <img  align="right" src="stulogoorg.png" alt="image"> -->
                </div>
 
 
            </div>
        </div>
    </section> 
    <footer class="background">
           
        <p class="text-footer">
             
            Copyright ©-All rights are reserved
        </p>
 
 
    </footer>
</body>
 
</html>


















