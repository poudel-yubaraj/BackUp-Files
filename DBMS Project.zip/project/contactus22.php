<!DOCTYPE html>
<html>
<head>
  <title></title>
  <style>
    /* CSS styles */

    body {
      margin: 0;
      padding: 0;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
    }

    div.login-box {
      border-radius: 5px;
      background-color: rgba(242, 242, 242, 0.8); /* Transparent background */
      padding: 20px;
      width: 350px; /* Set the width of the login box */
      position: relative; /* Add position relative for containing child elements */
    }

    input[type=text], input[type=number], input[type=password], select, textarea {
      width: 100%;
      padding: 12px 20px;
      margin: 8px 0;
      display: inline-block;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
    }

    input[type=submit] {
      width: 100%;
      background-color: #274160;
      color: white;
      padding: 14px 20px;
      margin: 8px 0;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }

    input[type=submit]:hover {
      opacity: 0.7;
    }

    div#error-msg {
      color: red;
      font-weight: bold;
      margin-top: 10px;
      text-align: center;
      color: #274160; /* Set the text color to #274160 */
    }

    div.login-footer {
      margin-top: 20px;
      text-align: center;
    }

    textarea {
      width: 100%;
      padding: 12px 20px;
      margin: 8px 0;
      display: inline-block;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
      resize: none; /* Prevent textarea from being resizable */
    }

    textarea {
      position: relative;
      z-index: 1;
    }
  </style>
  <script>
    // JavaScript validation
    function validateForm() {
      var firstname = document.getElementById('firstname').value;
      var lastname = document.getElementById('lastname').value;
      var contact = document.getElementById('contact').value;

      // Validate First Name (Allow only alphabetic characters)
      if (!/^[a-zA-Z]+$/.test(firstname)) {
        alert('Please enter a valid first name.');
        document.getElementById('firstname').focus();
        return false;
      }

      // Validate Last Name (Allow only alphabetic characters)
      if (!/^[a-zA-Z]+$/.test(lastname)) {
        alert('Please enter a valid last name.');
        document.getElementById('lastname').focus();
        return false;
      }

      // Validate Contact (Allow only numeric characters)
      if (!/^\d+$/.test(contact)) {
        alert('Please enter a valid contact number.');
        document.getElementById('contact').focus();
        return false;
      }

      return true;
    }
  </script>
</head>

<body>
  <div class="login-box">
    <h2 style="text-align: center; color: #274160;">CONTACT US</h2> <!-- Set the text color to #274160 -->
    <form action="contactprocess2.php" method="POST" name="myform" onsubmit="return validateForm();">
      <label for="firstname">First Name:</label>
      <input type="text" id="firstname" name="firstname" placeholder="Your first name.." required>

      <label for="lastname">Last Name:</label>
      <input type="text" id="lastname" name="lastname" placeholder="Your last name.." required>

      <label for="contact">Contact:</label>
      <input type="text" name="contact" id="contact" required>

      <label for="info">Message:</label>
      <textarea id="info" name="info" rows="8" placeholder="Type your message..." required></textarea>

      <input type="submit" value="Submit" name="submit">
    </form>
  </div>
</body>
</html>
