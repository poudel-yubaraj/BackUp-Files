<?php
session_start();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Display Booking Messages</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>
</head>
<body>

<script>
    Check if booking messages are available in session
    <?php if(isset($_SESSION['booking_msg'])): ?>
        <?php foreach($_SESSION['booking_msg'] as $message): ?>
            swal("<?php echo $message; ?>", "", "success"); // Display each message using SweetAlert
        <?php endforeach; ?>
        <?php unset($_SESSION['booking_msg']); ?> // Clear session variable after displaying messages
    <?php endif; ?>
</script>

</body>
</html>
