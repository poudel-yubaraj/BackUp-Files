<?php
session_start();
?>

<html>
<head>
  <title></title>
  <style>
    /* CSS styles */

    body {
      margin: 0;
      padding: 0;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
      background-image: url("images.jpg"); /* Replace "your-image.jpg" with the path to your background image */
      background-size: cover;
      background-position: center;
    }

    div.login-box {
      border-radius: 5px;
      background-color: rgba(242, 242, 242, 0.8); /* Transparent background */
      padding: 20px;
      width: 50%; /* Set the width to cover 50% of the screen */
    }

    input[type=text], input[type=number], input[type=password], select {
      width: 100%;
      padding: 12px 20px;
      margin: 8px 0;
      display: inline-block;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
    }

    input[type=submit] {
      width: 100%;
      background-color: #274160;
      color: white;
      padding: 14px 20px;
      margin: 8px 0;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }

    input[type=submit]:hover {
      opacity:0.7;
    }

    div#error-msg {
      color: red;
      font-weight: bold;
      margin-top: 10px;
      text-align: center;
      color: #274160; /* Set the text color to #274160 */
    }

    div.login-footer {
      margin-top: 20px;
      text-align: center;
    }
  </style>
  <script>
    // JavaScript validation
    function validateForm() {
      var email = document.getElementById('email').value;
      var password = document.getElementById('password').value;

      // Validate Email
      if (!validateEmail(email)) {
        document.getElementById('error-msg').innerHTML = 'Invalid Email! Please enter a valid email address.';
        return false;
      }

      return true;
    }

    // Email validation function
    function validateEmail(email) {
      var re = /\S+@\S+\.\S+/;
      return re.test(email);
    }
  </script>
</head>

<body>
  <div class="login-box">
    <h2 style="text-align: center; color: #274160;">STUDENT LOGIN</h2> <!-- Set the text color to #274160 -->
    <form action="" method="POST" onsubmit="return validateForm();">
      <label for="email">Enter Your Email:</label>
      <input type="text" id="email" name="email" required>

      <label for="password">Enter Your Password:</label>
      <input type="password" id="password" name="password" required>

      <input type="submit" value="Submit" name="submit">
      <div id="error-msg"></div>
    </form>

    <?php
      $count = 0;
      include 'connection3.php';
      if (isset($_POST['submit'])) {
        $email1 = $_POST['email'];
        $password1 = $_POST['password'];

        $query = "SELECT * FROM student_info";
        $result = mysqli_query($conn, $query);

        while ($row = mysqli_fetch_assoc($result)) {
          $email = $row['student_email'];
          $password = $row['student_password'];
          $dept_id = $row['dept_id'];
          $student_id = $row['student_id'];

          if (($email1 == $email) && ($password1 == $password)) {
            $count++;
            $_SESSION['dept_id'] = $dept_id;
            break;
          }
        }

        if ($count > 0) {
          echo "<div class='login-footer'>
                You Successfully Log In. Please click the next button to continue.
                <a href='afterloginstudent2.php?dept_id=$dept_id&student_id=$student_id'><button id='loginemp'>Next</button></a>
                </div>";
        } else {
          echo "<script>
                document.getElementById('error-msg').innerHTML = 'Sorry, either the Email or Password is invalid! Please try again!';
              </script>";
        }
      }
    ?>
  </div>
</body>
</html>
