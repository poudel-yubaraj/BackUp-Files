<!DOCTYPE html>
<html lang="en">
<head>
   
    <title>display</title>
    <link rel="stylesheet" href="style3.css">
</head>
<body>
    
    <!-- <a href="insert.php">  <button> Add+</button> </a><br><br> -->
              <table id="customers" border=1px width=100%>
              <caption style="caption-side:top;background-color:#4ae673;font-size:40px;"> Subjects</caption>
                <tr>
                    <th> Subject Id</th>
                    <th>Subject Name</th>
                    
                   
                   

                </tr>
               
               
           

                <!-- php code -->
                <?php      
                        $dept_id=$_GET['dept_id'];
                        $student_id=$_GET['student_id'];
                        include 'connection3.php';
                        $query="SELECT * FROM subject where  dept_id=$dept_id";
                        $result=mysqli_query($conn,$query);
                        // fetching the data from a database
                       // $row=mysqli_fetch_assoc($result);  
                        // echo $row['id']; for checking wether the data is fetched or not

                      while(  $row=mysqli_fetch_assoc($result)){
                        $subject_id=$row['subject_id'];
                        $subject_name=$row['subject_name'];
                      
                        
                        $dept_id=$row['dept_id'];

                        $query2="SELECT * FROM dept where dept_id=$dept_id";
               $result2=mysqli_query($conn,$query2);
              $row2=mysqli_fetch_assoc($result2);
              $dept_name=$row2['dept_name'];

             $faculty_id=$row2['faculty_id'];

             $query1="SELECT * FROM faculty where faculty_id=$faculty_id";
             $result1=mysqli_query($conn,$query1);
            $row1=mysqli_fetch_assoc($result1);
            $faculty_name=$row1['faculty_name'];
                       
                       
                    // echo $emp_id;
                       

                     
                    echo"   <tr>
                       <td>".$subject_id."</td>
                       <td>".$subject_name."</td>
                      
                      
                      

                </tr>";

                        
                      }
                ?>
                </table>
</body>
</html>