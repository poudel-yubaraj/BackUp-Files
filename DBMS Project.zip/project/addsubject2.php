<html>
    <head>
        <title></title>
        <link rel="stylesheet" href="style3.css">


        <script type="text/javascript">
                function validate()
                    {    var regName = /^[a-zA-Z]+$/;
                         var regPhone = /^98\d{8}$/;
                        var x=document.myform.email.value;
                       // var num=document.myform.contact.value;
                         var num = document.getElementById('contact').value
                      //  alert(num);
                        var name=document.myform.fname.value;
                        var lname=document.myform.faculty_name.value;
                        var password=document.myform.password.value;
                        const userDateInput = document.getElementById('userDate').value;
                        const userDate = new Date(userDateInput);
                        const currentDate = new Date();
                        const differenceMs = Math.abs(currentDate -userDate );
                        const differenceDays = Math.floor(differenceMs / (1000 * 60 * 60 * 24));
                        
//                         const resultElement = document.getElementById('result');
//   resultElement.textContent = `Difference in days: ${differenceDays}`;
                        var atpos=x.indexOf('@');
                        var dotpos=x.lastIndexOf('.');
                        // if(document.myform.name.value=="")
                        //     {
                        //         alert("Please Provide the name");
                        //         document.myform.name.focus();
                        //         return false;
                        //     }

                       if(!regName.test(name)){
       alert('Please enter valid first name.');
     //  document.getElementById('ffname').value="please enter the valid name";
        document.getElementById('fname').focus();
        return false;}
    // }else{
    //     alert('Valid name given.');
        
    // }
    if(!regName.test(lname)){
       alert('Please enter valid last name.');
     //  document.getElementById('ffname').value="please enter the valid name";
        document.getElementById('lname').focus();
        return false;}

        if(! regPhone.test(num)){
       alert('Please enter valid phone number');
       //document.getElementById('fname').value="please enter the valid name";
        document.getElementById('contact').focus();
        return false;}




           if(password.length<6){
     //  document.getElementById('ppassword').value="please enter the longer password";
      alert("please enter the password greator than 6 character");
               return false;
           }


          if(differenceDays<5475 ){
            alert("Employee is less than 16 years old so it cannot be happen");
            return false;
          }



    if((document.myform.email.value=="") || (atpos<1||dotpos<atpos+2||dotpos+2>=x.length))
                                {
                                    alert("Please Provide Valid Email")
                                    document.myform.email.focus();
                                    return false;
                                }
                            if(document.myform.zip.value==""||isNaN(document.myform.zip.value)||
                            document.myform.zip.value.length!=5)
                                {   
                                    alert("Please Provide a zip in the format #####");
                                    document.myform.zip.focus();
                                    return false;
                                }
                            if(document.myform.country.value=="-1")
                                {
                                    alert("Please provide your country");
                                    return false;
                                }
 
//                                 if (isNaN(num)){  
//                                 alert("please enter numeric value only");
//   document.getElementById("numloc").innerHTML="Enter Numeric value only";  
//   return false;  
// }else{  
//   return true;  
//   } 


           
          alert("All fields are filled.\n Thank you ");
                            exit();
                    }
            </script>
    </head>


<body>
    <div>

    <form action="addsubjectprocess2.php" method="POST" name="myform" onsubmit="return validate()">

    <label for="subject_id">Subject ID</label><span id="subject_id"></span>
    <input type="text" id="subject_id" name="subject_id" placeholder="eg.BEGCO101" required>



    

    <label for="subject_name">Subject Name</label><span id="subject_name"></span>
    <input type="text" id="subject_name" name="subject_name" placeholder="eg.Math" required>

       <?php
        include 'connection3.php';
    $query="SELECT * FROM faculty";
     $result=mysqli_query($conn,$query); 
     ?>
 Faculty Name:
<select name="faculty_name" id="faculty_name"  required>
<option value="" selected="selected" disabled="disabled">- - Select faculty- -</option>
<?php
  while($row=mysqli_fetch_assoc($result)){

	?>
<option value="<?php echo $row['faculty_name'];?>"><?php echo $row['faculty_name'];?></option>
<?php } ?>
</select>





<?php
        include 'connection3.php';
    $query1="SELECT * FROM dept";
     $result1=mysqli_query($conn,$query1); 
     ?>
  Department Name:
<select name="dept_name" id="dept_name"  required>
<option value="" selected="selected" disabled="disabled">- - Select department - -</option>
<?php
  while($row1=mysqli_fetch_assoc($result1)){

	?>
<option value="<?php echo $row1['dept_name'];?>"><?php echo $row1['dept_name'];?></option>
<?php } ?>
</select>









   
    <input type="submit" value="Submit" name="submit">
  </form>

    </div>
</body>
</html>