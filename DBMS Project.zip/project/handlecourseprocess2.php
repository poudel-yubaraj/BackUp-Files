<?php
       include 'connection3.php';
       if(isset($_POST['submit'])){
          
          $subject_name=$_POST['subject_name'];       
          $dept_name=$_POST['dept_name'];
          $duration=$_POST['duration'];
        $query2="SELECT * FROM dept where dept_name='$dept_name'";
     $result2=mysqli_query($conn,$query2);
      $row2=mysqli_fetch_array($result2);
               
               $dept_id=$row2['dept_id'];
          //   echo  $dept_id;
             
          
       
          $query3 = "INSERT INTO course (`dept_id`, `course_name`, `duration`) VALUES ('$dept_id','$subject_name','$duration');";
         $result = mysqli_query($conn,$query3);
         if($result){
           echo "course added sucessfully";
           echo"<a href='afterlogindepartment2.php?dept_id=$dept_id'>Click Here to proceed.</a> ";
         }
          else{
           die(mysqli_error($result));
         }
       }
?>