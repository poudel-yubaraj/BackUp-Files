<html>
    <head>
        <title></title>
        <link rel="stylesheet" href="style3.css">


        <script type="text/javascript">
                function validate()
                    {    var regName = /^[a-zA-Z]+$/;
                         var regPhone = /^98\d{8}$/;
                        var x=document.myform.email.value;
                       // var num=document.myform.contact.value;
                         var num = document.getElementById('contact').value
                      //  alert(num);
                        var name=document.myform.fname.value;
                        var lname=document.myform.lname.value;
                        var password=document.myform.password.value;
                        const userDateInput = document.getElementById('userDate').value;
                        const userDate = new Date(userDateInput);
                        const currentDate = new Date();
                        const differenceMs = Math.abs(currentDate -userDate );
                        const differenceDays = Math.floor(differenceMs / (1000 * 60 * 60 * 24));
                        
//                         const resultElement = document.getElementById('result');
//   resultElement.textContent = `Difference in days: ${differenceDays}`;
                        var atpos=x.indexOf('@');
                        var dotpos=x.lastIndexOf('.');
                        // if(document.myform.name.value=="")
                        //     {
                        //         alert("Please Provide the name");
                        //         document.myform.name.focus();
                        //         return false;
                        //     }

                       if(!regName.test(name)){
       alert('Please enter valid first name.');
     //  document.getElementById('ffname').value="please enter the valid name";
        document.getElementById('fname').focus();
        return false;}
    // }else{
    //     alert('Valid name given.');
        
    // }
    if(!regName.test(lname)){
       alert('Please enter valid last name.');
     //  document.getElementById('ffname').value="please enter the valid name";
        document.getElementById('lname').focus();
        return false;}

        if(! regPhone.test(num)){
       alert('Please enter valid phone number');
       //document.getElementById('fname').value="please enter the valid name";
        document.getElementById('contact').focus();
        return false;}




           if(password.length<6){
     //  document.getElementById('ppassword').value="please enter the longer password";
      alert("please enter the password greator than 6 character");
               return false;
           }


          if(differenceDays<5475 ){
            alert("Employee is less than 16 years old so it cannot be happen");
            return false;
          }



    if((document.myform.email.value=="") || (atpos<1||dotpos<atpos+2||dotpos+2>=x.length))
                                {
                                    alert("Please Provide Valid Email")
                                    document.myform.email.focus();
                                    return false;
                                }
                            if(document.myform.zip.value==""||isNaN(document.myform.zip.value)||
                            document.myform.zip.value.length!=5)
                                {   
                                    alert("Please Provide a zip in the format #####");
                                    document.myform.zip.focus();
                                    return false;
                                }
                            if(document.myform.country.value=="-1")
                                {
                                    alert("Please provide your country");
                                    return false;
                                }
 
//                                 if (isNaN(num)){  
//                                 alert("please enter numeric value only");
//   document.getElementById("numloc").innerHTML="Enter Numeric value only";  
//   return false;  
// }else{  
//   return true;  
//   } 


           
          alert("All fields are filled.\n Thank you ");
                            exit();
                    }
            </script>
    </head>
</html>

<body>





<?php
               include 'connection3.php';
               $student_id=$_GET['student_id'];
               $dept_id=$_GET['dept_id'];
              // echo $dept_id;
               
               $query="SELECT * FROM student_info where student_id=$student_id";
               $result=mysqli_query($conn,$query);
               $row=mysqli_fetch_assoc($result);
            //    echo $row['name'];
               ?>
    <div>

    <form action=" " method="POST" name="myform" onsubmit="return validate()">
    <label for="student_name">Student Name</label><span id="name"></span>
    <input type="text" id="student_name" name="student_name" value="<?php echo $row['student_name'];?>"  required>

    

    <label for="student_email">Email</label><span id="eemail"></span>
    <input type="text" id="student_email" name="student_email" value="<?php echo $row['student_email'];?>"  required>

    <label for="student_password">Password</label><span id="ppassword"></span>
    <input type="text" id="student_password" name="student_password" value="<?php echo $row['student_password'];?>"  required>

    
       
        <label for="student_gpa">GPA</label>
        <input type="text" name="student_gpa" id="student_gpa" value="<?php echo $row['student_gpa'];?>"  required>

       
        <label for="student_dob">DOB</label>
        <input type="date" name="student_dob" id="userDate"  value="<?php echo $row['student_dob'];?>" required>  <br>

        <!-- <label for="contact">Salary</label>
        <input type="text" name="salary" id="f1" >  -->

    <input type="submit" value="Submit" name="submit">
  </form>

    </div>
</body>

<?php
       include 'connection3.php';
              $dept_id=$_GET['dept_id'];
              $student_id=$_GET['student_id'];
            //  echo $dept_id;
       if(isset($_POST['submit'])){
          $student_name=$_POST['student_name'];
          //echo $firstname;
        
          $student_email=$_POST['student_email'];
          $student_password=$_POST['student_password'];
          $student_gpa=$_POST['student_gpa'];
          $student_dob=$_POST['student_dob'];
          
  $query="SELECT * FROM dept where dept_id=$dept_id";
               $result=mysqli_query($conn,$query);
              $row=mysqli_fetch_assoc($result);
              $dept_name=$row['dept_name'];
             $faculty_id=$row['faculty_id'];
           
           //  echo $faculty_id;


             $query1="SELECT * FROM faculty where faculty_id=$faculty_id";
               $result1=mysqli_query($conn,$query1);
              $row1=mysqli_fetch_assoc($result1);
              $faculty_name=$row1['faculty_name'];
            

         // $query3 = "INSERT INTO student_info (`student_name`, `student_dob`, `student_gpa`, `student_email`, `student_password`, `faculty_id`, `dept_id`) VALUES ('$student_name','$student_dob','$student_gpa','$student_email','$student_password','$faculty_id','$dept_id');";
          $query3="UPDATE student_info SET student_name='$student_name', student_dob='$student_dob' ,student_gpa='$student_gpa',student_email='$student_email',student_password='$student_password'  WHERE  dept_id=$dept_id and student_id=$student_id";
          $result3 = mysqli_query($conn,$query3);
         if($result3){
           echo " Updated sucessfully";
           echo"<a href='afterlogindepartment2.php?dept_id=$dept_id'>Click Here to proceed.</a> ";
 
        // header('location:adminmainpage2.php');
         }
          else{
           die(mysqli_error($result));
         }
       }
?>