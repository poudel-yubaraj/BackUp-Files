<!DOCTYPE html>
<html lang="en">
<head>
   
    <title>display</title>
    <link rel="stylesheet" href="style3.css">
</head>
<body>
    
    <!-- <a href="insert.php">  <button> Add+</button> </a><br><br> -->
              <table id="customers" border=1px width=100%>
              <caption style="caption-side:top;background-color:#4ae673;font-size:40px;">Faculty List</caption>
                <tr>
                    <th> Faculty ID</th>
                    <th>Faculty Name</th>
                   

                </tr>
               
               
           

                <!-- php code -->
                <?php
                        include 'connection3.php';
                        $query="SELECT * FROM faculty";
                        $result=mysqli_query($conn,$query);
                        // fetching the data from a database
                       // $row=mysqli_fetch_assoc($result);  
                        // echo $row['id']; for checking wether the data is fetched or not

                        while($row=mysqli_fetch_assoc($result)){
                        $faculty_id=$row['faculty_id'];
                        $faculty_name=$row['faculty_name'];
                       
                       
                    // echo $emp_id;
                       

                     
                    echo"   <tr>
                       <td>".$faculty_id."</td>
                       <td>".$faculty_name."</td>
                      
                      
                </tr>";

                        }

                ?>
                </table>
</body>
</html>