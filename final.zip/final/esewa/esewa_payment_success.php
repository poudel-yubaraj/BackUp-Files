<?php
include '../components/connect.php';

if (
    isset($_REQUEST['oid']) &&
    isset($_REQUEST['amt']) &&
    isset($_REQUEST['refId'])
) {
    
    $sql = "SELECT * FROM property WHERE id = :oid";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':oid', $_REQUEST['oid']);
    $stmt->execute();
    
    $rowCount = $stmt->rowCount();
    if ($rowCount == 1) {
        $order = $stmt->fetch(PDO::FETCH_ASSOC);
        $url = "https://uat.esewa.com.np/epay/transrec";

        $data = [
            'amt' => $order['royalty'],
            'rid' => $_REQUEST['refId'],
            'pid' => $order['id'],
            'scd' => 'epay_payment'
        ];

        $curl = curl_init($url);
        curl_setopt($curl, CURLOPT_POST, true);
        curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($curl);
        $response_code = get_xml_node_value('response_code', $response);

        if (trim($response_code) == 'Success') {
            $sql = "UPDATE property SET royalty_payment = 1 WHERE id = :id";
            $stmt = $conn->prepare($sql);
            $stmt->bindParam(':id', $order['id']);
            $stmt->execute();
            $esewa_msg_sucess[]='Payment is Sucessfull.!';
         //   echo 'Thank you for purchasing with us. Your payment has been successful.';
           // header('Location: success.php');
          //  exit(); // Always exit after a header redirect
        }
    }
}

function get_xml_node_value($node, $xml) {
    if ($xml === false) {
        return false;
    }
    $found = preg_match('#<' . $node . '(?:\s+[^>]+)?>(.*?)' . '</' . $node . '>#s', $xml, $matches);
    if ($found !== false) {
        return $matches[1];
    }

    return false;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Date Selection and Photo Insertion</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>
</head>
<body></body>
</html>

<?php foreach($esewa_msg_sucess as $message): ?>
<script>
    swal("<?php echo $message; ?>", "", "success").then(function() {
        window.location.href = "home.php"; // Redirect to home.php after the SweetAlert is closed
    });
</script>
<?php endforeach; ?>